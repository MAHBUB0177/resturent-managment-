import React from 'react'

const RoomsFilter = () => {
  return (
    <div>RoomsFilter</div>
  )
}

export default RoomsFilter