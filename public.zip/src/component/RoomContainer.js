import React from 'react'
import RoomsFilter from './RoomsFilter'
import RoomsList from './RoomsList'
import { RoomConsumer, withRoomConsumer } from '../context'
import { Loading } from './Loading'

function RoomContainer({context}){
    const{loading,sortedRooms,rooms}=context;

    if(loading){
    return <div style={{display:'flex',alignItems:'center',justifyContent:'center'}}>
        <Loading/>
    </div>
    }
    return(
        <div>
        <RoomsFilter rooms={rooms}/>
        <RoomsList rooms={sortedRooms}/>
    </div>
    )
}


export default withRoomConsumer(RoomContainer)
// const RoomContainer = () => {
//   return (
//     <RoomConsumer>
//         {
//             value=>{
//                 const{loading,sortedRooms,rooms}=value;
//                 if(loading){
//                     return <div style={{display:'flex',alignItems:'center',justifyContent:'center'}}>
//                         <Loading/>
//                     </div>
//                 }
//                 return(
//                     <div>
//                     <h2> RoomContainer</h2>
//                      <RoomsFilter rooms={rooms}/>
//                      <RoomsList rooms={sortedRooms}/>
//                  </div>
//                 )
//             }
//         }

//     </RoomConsumer>
   
//   )
// }

// export default RoomContainer